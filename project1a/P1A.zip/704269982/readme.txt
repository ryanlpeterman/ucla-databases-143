Project 1A:

Overall Method:
    1. Inserted a form into the HTML that would handle the input as a GET request
    2. This made the input available to the PHP code by the global $_GET array
    3. Checked input with a regex to match a valid mathematical expression
    4. If the mathematical expression was matched perfectly 
        -i.e. the length of the match was equal to the input string
        then we displayed the input with whitespaces removed
        and we displayed what the input evaluated to
    5. Otherwise, we printed that the expression was invalid
    6. Also if division by 0 exception is thrown we catch it to state the fact
Work Split:
    
    50% Ryan 
    50% Max

    - We pair programmed for the entire project so it was an even contribution
    from both partners
